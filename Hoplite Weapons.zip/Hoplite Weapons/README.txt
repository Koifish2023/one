Merge both files into the original files in your 'plugins' folder.

Dependencies:

ExecutableItems PREMIUM
SCore by Ssmomar